'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const {randomBytes, randomInt} = require('node:crypto');
const world = require('./world.json');
const {controlBot} = require('./bots.cjs');
const {obstacles, piles, targets} = world;
const MAX_HP = 3, MAX_AMMO = 3, BALL_RADIUS = .12, PLAYER_RADIUS = .4;
const BODY = [[.44,.44],[1.02,.35],[1.52,.27]];
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const DT = .025, LOST_SEAT_MS = 15000;

const opposing = side => side === 'blue' ? 'red' : 'blue';
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const finite = (value, otherwise = 0) => Number.isFinite(value) ? value : otherwise;
const online = player => player.bot || Boolean(player.stream);
const people = room => [...room.players.values()].filter(player => !player.bot);
const waitingForPlayer = room => people(room).some(player=>!player.stream);
const modes = {team:4,coop:2,duel:2};
const freshInput = () => ({mx:0,my:0,gather:false,crouch:false});
const nearPile = player => piles.some(pile => Math.hypot(player.x-pile.x, player.z-pile.z) < 1.9);

function resolveWall(player, wall) {
  const dx = player.x - clamp(player.x, wall.minX, wall.maxX);
  const dz = player.z - clamp(player.z, wall.minZ, wall.maxZ);
  const distance = Math.hypot(dx, dz);
  if (distance >= PLAYER_RADIUS) return;
  if (distance > 0) {
    const scale = (PLAYER_RADIUS-distance)/distance;
    player.x += dx*scale; player.z += dz*scale;
    return;
  }
  const distances = [player.x-wall.minX, wall.maxX-player.x, player.z-wall.minZ, wall.maxZ-player.z];
  const side = distances.indexOf(Math.min(...distances));
  if (side===0) player.x=wall.minX-PLAYER_RADIUS;
  if (side===1) player.x=wall.maxX+PLAYER_RADIUS;
  if (side===2) player.z=wall.minZ-PLAYER_RADIUS;
  if (side===3) player.z=wall.maxZ+PLAYER_RADIUS;
}

function separate(player, other, minimum) {
  const dx=player.x-other.x, dz=player.z-other.z, distance=Math.hypot(dx,dz);
  if (distance >= minimum || distance === 0) return;
  const scale=(minimum-distance)/distance;
  player.x += dx*scale; player.z += dz*scale;
}

function begin(room) {
  room.hp = {blue:MAX_HP, red:MAX_HP};
  room.balls = []; room.winner = null; room.phase = 'play'; room.round++;
  for (const side of ['blue','red']) {
    const members = [...room.players.values()].filter(player => player.side===side);
    members.forEach((player,index) => {
      Object.assign(player,{
        x: index===0 ? -.85 : .85, z: side==='blue' ? 18.5 : -18.5,
        yaw: side==='blue' ? 0 : Math.PI, pitch:.3, ammo:MAX_AMMO,
        input:freshInput(), inputAt:0, gatherTime:0, crouch:false, gathering:false,
        stun:0, invulnerable:0, cooldown:0, throwAnim:0, shotUntil:0, shot:0, hit:0,
        route:null, refilling:false, blockedReload:null, nextShotAt:0, station:0,
      });
    });
  }
}

function fire(room, player) {
  const {yaw,pitch}=player, sin=Math.sin(yaw), cos=Math.cos(yaw), speed=15;
  room.balls.push({
    id:++room.ballId, side:player.side, x:player.x+.3*(cos-sin), y:1.55, z:player.z-.3*(sin+cos),
    vx:-sin*Math.cos(pitch)*speed, vy:Math.sin(pitch)*speed, vz:-cos*Math.cos(pitch)*speed, age:0,
  });
  player.ammo--; player.cooldown=.34; player.throwAnim=.28; player.shot++;
  player.gatherTime=0;
}

function movePlayers(room, now) {
  for (const player of room.players.values()) {
    player.cooldown=Math.max(0,player.cooldown-DT);
    player.stun=Math.max(0,player.stun-DT);
    player.invulnerable=Math.max(0,player.invulnerable-DT);
    player.throwAnim=Math.max(0,player.throwAnim-DT);
    if(player.bot) controlBot(player,now,nearPile);
    const active=player.bot || (Boolean(player.stream) && now-player.inputAt < 400);
    const input=active ? player.input : freshInput();
    if(active && player.shotUntil>now && !player.stun && !player.cooldown && player.ammo){
      fire(room,player);player.shotUntil=0;
    } else if(!active || player.shotUntil<=now || !player.ammo) player.shotUntil=0;
    player.gathering=input.gather && !player.stun && !player.throwAnim && player.ammo<MAX_AMMO && nearPile(player);
    player.crouch=input.crouch || player.gathering;
    if (player.gathering) {
      player.gatherTime+=DT;
      if (player.gatherTime>=.75-1e-6) {player.ammo++; player.gatherTime=0;}
    } else player.gatherTime=0;
    if (player.stun || player.gathering) continue;
    const speed=(player.crouch?2:player.bot?3.35:4.6)*DT, length=Math.max(1,Math.hypot(input.mx,input.my));
    const mx=input.mx/length, my=input.my/length;
    player.x+= (Math.cos(player.yaw)*mx-Math.sin(player.yaw)*my)*speed;
    player.z+= (-Math.sin(player.yaw)*mx-Math.cos(player.yaw)*my)*speed;
    for (const other of room.players.values()) if (other!==player && online(other)) separate(player,other,.8);
    if(room.mode!=='duel') for (const target of Object.values(targets)) separate(player,target,.84);
    for(let pass=0;pass<2;pass++) for(const wall of obstacles) resolveWall(player,wall);
    player.x=clamp(player.x,-10.6,10.6); player.z=clamp(player.z,-21.6,21.6);
  }
}

function hurtSide(room,side,attacker){
  room.hp[side]--;
  if (!room.hp[side]) {room.winner=attacker; room.phase='result';}
}
function impacts(room, ball) {
  for (const player of room.players.values()) {
    if (!online(player) || player.side===ball.side) continue;
    if (Math.hypot(ball.x-player.x,ball.z-player.z)<.48 && ball.y>0 && ball.y<(player.crouch?1:1.62)+BALL_RADIUS) {
      if (!player.invulnerable) {
        player.stun=.45; player.invulnerable=1.25; player.hit++;
        if(room.mode==='duel') hurtSide(room,player.side,ball.side);
      }
      return true;
    }
  }
  const side = opposing(ball.side), target=targets[side];
  if (room.mode!=='duel' && BODY.some(([y,r]) => Math.hypot(ball.x-target.x,ball.y-y,ball.z-target.z)<r+BALL_RADIUS)) {
    hurtSide(room,side,ball.side);
    return true;
  }
  return ball.y<BALL_RADIUS || obstacles.some(o =>
    ball.y<o.h+BALL_RADIUS && ball.x>o.minX-BALL_RADIUS && ball.x<o.maxX+BALL_RADIUS &&
    ball.z>o.minZ-BALL_RADIUS && ball.z<o.maxZ+BALL_RADIUS);
}

function moveBalls(room) {
  const substep=DT/3;
  for (let i=room.balls.length-1; i>=0; i--) {
    const ball=room.balls[i];
    ball.age+=DT;
    let dead=ball.age>6;
    for (let n=0;n<3 && !dead;n++) {
      ball.vy-=9.8*substep;
      ball.x+=ball.vx*substep; ball.y+=ball.vy*substep; ball.z+=ball.vz*substep;
      dead=impacts(room,ball);
      if (room.phase==='result') {room.balls=[]; return;}
    }
    if (dead) room.balls.splice(i,1);
  }
}

function snapshot(room) {
  return {
    code:room.code, mode:room.mode, capacity:room.capacity, phase:room.phase, host:room.host, round:room.round, winner:room.winner, hp:room.hp,
    waiting:room.phase==='play' && waitingForPlayer(room),
    players:[...room.players.values()].map(p => ({
      id:p.id,name:p.name,side:p.side,bot:Boolean(p.bot),connected:online(p),x:p.x,z:p.z,yaw:p.yaw,pitch:p.pitch,
      ammo:p.ammo,crouch:p.crouch,gathering:p.gathering,gatherTime:p.gatherTime,throwAnim:p.throwAnim,shot:p.shot,hit:p.hit,
    })),
    balls:room.balls.map(({id,x,y,z})=>({id,x,y,z})),
  };
}

function broadcast(room) {
  const data='data: '+JSON.stringify(snapshot(room))+'\n\n';
  for (const player of room.players.values()) {
    if(player.stream && player.stream.writableLength<65536) player.stream.write(data);
  }
}

function removePlayer(room, player) {
  room.players.delete(player.id);
  if (player.stream) player.stream.end();
  if (room.host===player.id) room.host=people(room)[0]?.id ?? null;
  if (room.phase==='play') {room.phase='result';room.winner='interrupted';room.balls=[];}
  broadcast(room);
}

function send(response,status,body) {
  response.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  response.end(JSON.stringify(body));
}

async function readBody(request) {
  let body='';
  for await (const chunk of request) {
    body+=chunk;
    if(body.length>4096) throw new Error('Too large');
  }
  const data=JSON.parse(body);
  if(!data || typeof data!=='object' || Array.isArray(data)) throw new Error('Invalid JSON');
  return data;
}

function lanAddresses(port) {
  try {
    return Object.values(os.networkInterfaces()).flat().filter(i=>i && i.family==='IPv4' && !i.internal)
      .map(i=>'http://'+i.address+':'+port);
  } catch {
    return [];
  }
}

function createServer() {
  const rooms=new Map();
  const htmlPath=path.join(__dirname,'snowball-alley.html');
  const server=http.createServer(async (request,response) => {
    const url=new URL(request.url,'http://localhost');
    if(request.method==='GET' && ['/', '/snowball-alley.html'].includes(url.pathname)) {
      response.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
      const stream=fs.createReadStream(htmlPath);
      stream.on('error',()=>response.end());
      stream.pipe(response);
      return;
    }
    if(request.method==='GET' && url.pathname==='/api/info') {
      send(response,200,{addresses:lanAddresses(server.address().port)}); return;
    }
    if(request.method==='GET' && url.pathname==='/api/events') {
      const room=rooms.get(url.searchParams.get('code'));
      const player=room?.players.get(url.searchParams.get('id'));
      if(!player || player.bot || player.token!==url.searchParams.get('token')) {send(response,403,{error:'참가 정보를 확인해 주세요.'});return;}
      const oldStream=player.stream;
      player.stream=response;
      if(oldStream) oldStream.end();
      response.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache','X-Accel-Buffering':'no'});
      response.write(': connected\n\n');
      response.on('close',()=>{
        if(player.stream!==response) return;
        player.stream=null;player.disconnectedAt=Date.now();
        for(const member of people(room)){member.input=freshInput();member.inputAt=0;member.shotUntil=0;}
        broadcast(room);
      });
      broadcast(room);
      return;
    }
    if(request.method!=='POST' || !['/api/room','/api/action'].includes(url.pathname)) {send(response,404,{error:'주소를 확인해 주세요.'});return;}
    if (!String(request.headers['content-type']).startsWith('application/json')) {
      send(response,415,{error:'요청 형식을 확인해 주세요.'});return;
    }
    let data;
    try {data=await readBody(request);} catch {send(response,400,{error:'요청을 확인해 주세요.'});return;}
    if(url.pathname==='/api/room') {
      const requested=typeof data.code==='string'?data.code.trim().toUpperCase():'';
      let room=rooms.get(requested);
      if(requested && !room) {send(response,404,{error:'방 코드가 맞는지 확인해 주세요.'});return;}
      if(!room) {
        if(rooms.size>=32) {send(response,409,{error:'지금은 새 방을 열 수 없어요.'});return;}
        let code;
        do {code=Array.from({length:5},()=>ALPHABET[randomInt(ALPHABET.length)]).join('');} while(rooms.has(code));
        const mode=typeof data.mode==='string'&&Object.hasOwn(modes,data.mode)?data.mode:'team';
        room={code,mode,capacity:modes[mode],host:null,players:new Map(),phase:'lobby',round:0,winner:null,
          hp:{blue:3,red:3},ballId:0,balls:[]};
        if(mode==='coop') for(let i=0;i<2;i++) {
          const id='bot-'+i;
          room.players.set(id,{id,bot:true,botIndex:i,side:'red',name:'컴퓨터 '+(i+1)});
        }
        rooms.set(code,room);
      }
      if(room.phase==='play' || people(room).length>=room.capacity) {
        send(response,409,{error:room.phase==='play'?'경기가 진행 중이에요.':'방의 자리가 모두 찼어요.'});return;
      }
      const blue=[...room.players.values()].filter(p=>p.side==='blue').length;
      const name=(typeof data.name==='string'?data.name.trim():'').slice(0,14) || '참가자 '+(people(room).length+1);
      const player={
        id:randomBytes(6).toString('hex'),token:randomBytes(18).toString('hex'),name,
        side:room.mode==='coop'||blue<=room.players.size-blue?'blue':'red',stream:null,disconnectedAt:Date.now(),fire:0,
      };
      room.players.set(player.id,player);
      room.host??=player.id;
      send(response,200,{code:room.code,id:player.id,token:player.token});
      broadcast(room);
      return;
    }
    const room=rooms.get(data.code), player=room?.players.get(data.id);
    if(!player || player.bot || player.token!==data.token) {send(response,403,{error:'방에 다시 들어와 주세요.'});return;}
    if(data.type==='start') {
      if(player.id!==room.host) {send(response,403,{error:'방장만 경기를 시작할 수 있어요.'});return;}
      const members=people(room);
      if(room.phase==='play' || members.length!==room.capacity || members.some(p=>!p.stream)) {
        send(response,409,{error:'참가자가 모두 접속하면 시작할 수 있어요.'});return;
      }
      begin(room);broadcast(room);
    } else if(data.type==='leave') {
      removePlayer(room,player);
    } else if(data.type==='input') {
      if(room.phase==='play' && player.stream && !waitingForPlayer(room) && (data.round===undefined || data.round===room.round)) {
        player.input={mx:clamp(finite(data.mx),-1,1),my:clamp(finite(data.my),-1,1),crouch:data.crouch===true,gather:data.gather===true};
        player.yaw=finite(data.yaw,player.yaw)%(2*Math.PI);
        player.pitch=clamp(finite(data.pitch,player.pitch),-.12,1.25);
        player.inputAt=Date.now();
        if(Number.isSafeInteger(data.fire) && data.fire>player.fire) {player.fire=data.fire;player.shotUntil=Date.now()+200;}
      }
    } else {
      send(response,400,{error:'요청을 확인해 주세요.'});return;
    }
    send(response,200,{ok:true});
  });
  let tick=0;
  const timer=setInterval(()=>{
    const now=Date.now();
    for(const [code,room] of rooms) {
      for(const p of people(room)) if(!p.stream && now-p.disconnectedAt>LOST_SEAT_MS) removePlayer(room,p);
      if(!people(room).length) {rooms.delete(code);continue;}
      if(room.phase==='play') {
        if(!waitingForPlayer(room)){movePlayers(room,now);moveBalls(room);}
        if(tick%2===0 || room.phase==='result') broadcast(room);
      } else if(tick%40===0) broadcast(room);
    }
    tick++;
  },DT*1000);
  timer.unref();
  server.once('close',()=>clearInterval(timer));
  return server;
}

if(require.main===module) {
  const port=Number(process.env.PORT || process.argv[2] || 8765);
  const server=createServer();
  server.on('error',error=>{console.error(error.message);process.exitCode=1;});
  server.listen(port,'0.0.0.0',()=>{
    const actual=server.address().port;
    console.log('\nSnowball Alley - Multiplayer\n');
    console.log('This PC: http://localhost:'+actual);
    for(const url of lanAddresses(actual)) console.log('Same Wi-Fi: '+url);
    console.log('\nKeep this window open during the match.\n');
  });
}
module.exports={createServer};
